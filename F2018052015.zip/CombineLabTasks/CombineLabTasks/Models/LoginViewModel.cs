﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;

namespace CombineLabTasks.Models
{
    public class LoginViewModel
    {
        Login login = new Login();

        public void Signup(Login login)
        {
            string constring = ConfigurationManager.ConnectionStrings["dbtask"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constring))
            {

                con.Open();
                string insert = "INSERT INTO login(Username,Password) VALUES('" + login.Username + "','" + login.Password + "')";
                using (SqlCommand cmd = new SqlCommand(insert, con))
                {
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
        }
        public void log_in(Login login)
        {
            string constring = ConfigurationManager.ConnectionStrings["dbtask"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constring))
            {
                con.Open();
                string retrive = "SELECT * FROM login where Username ='" + login.Username + "' and Password ='" + login.Password + "' ";
                using (SqlCommand cmd = new SqlCommand(retrive, con))
                {
                    cmd.ExecuteNonQuery();

                    con.Close();
                }
            }
        }
        public void forgot_pass(Login login)
        {
            string constring = ConfigurationManager.ConnectionStrings["dbtask"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constring))
            {
                con.Open();
                string insert = "UPDATE login SET Password='" + login.Password + "'";
                using (SqlCommand cmd = new SqlCommand(insert, con))
                {
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
        }
        public List<Login> GetList()
        {
            Login questions = new Login();
            string constring = ConfigurationManager.ConnectionStrings["dbtask"].ConnectionString;
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            string retrive = "SELECT * FROM login";
            SqlCommand cmd = new SqlCommand(retrive, con);
            var model = new List<Login>();
            List<Login> question = new List<Login>();
            SqlDataReader dr = default(SqlDataReader);
            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                var Test = new Login();
                Test.Username = Convert.ToString(dr["Username"]);
                Test.Password = Convert.ToString(dr["Password"]);

                question.Add(Test);
            }
            return question;
        }
    }
}