﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using System.Text;

//namespace CombineLabTasks.Controllers
namespace CombineLabTasks.Models
{
    
    public class DefaultController : Controller
    {
      
        Login login = new Login();
        // GET: Default
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Index(Login login)
        {
            LoginViewModel exam = new LoginViewModel();
            string constring = ConfigurationManager.ConnectionStrings["dbtask"].ConnectionString;
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            string retrive = "SELECT * FROM login where Username='" + login.Username + "' and Password='" + login.Password + "'";
            SqlCommand cmd = new SqlCommand(retrive, con);
            SqlDataReader dr = default(SqlDataReader);
            dr = cmd.ExecuteReader();
            if (dr.Read() == true)
            {
                string uname = dr["Username"].ToString();
                string upass = dr["Password"].ToString();

                if ((login.Username == uname) && (login.Password == upass))
                {
                    ViewBag.Message = "User Already Exist";
                }
            }
            else
            {
                if (ModelState.IsValid)
                {
                    exam.Signup(login);
                    ViewBag.Message = "Login Successfully";
                    return RedirectToAction("Login");
                }

            }


            dr.Close();
            cmd.ExecuteNonQuery();
            con.Close();
            return View();
        }
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(Login login)
        {
            LoginViewModel exam = new LoginViewModel();
            string constring = ConfigurationManager.ConnectionStrings["dbtask"].ConnectionString;
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            string retrive = "SELECT * FROM login where Username='" + login.Username + "' and Password='" + login.Password + "'";
            SqlCommand cmd = new SqlCommand(retrive, con);
            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.Read() == true)
            {
              
                string uname = dr["Username"].ToString();
                string upass = dr["Password"].ToString();

                if ((login.Username == uname) && (login.Password == upass))
                {
                    ViewBag.Message = "Login Successfully";
                    return RedirectToAction("Index");

                }
            }
            else
            {
                ViewBag.Message = "not found";
            }


            dr.Close();
            cmd.ExecuteNonQuery();
            con.Close();
            return View();
        }
        public ActionResult Forgot_Password()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Forgot_Password(Login login)
        {
            LoginViewModel exam = new LoginViewModel();
            string constring = ConfigurationManager.ConnectionStrings["dbtask"].ConnectionString;
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            string retrive = "SELECT * FROM login where Username='" + login.Username + "'";
            SqlCommand cmd = new SqlCommand(retrive, con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read() == true)
            {
                string uname = dr["Username"].ToString();              
                if ((login.Username == uname))
                {
                    
                        exam.forgot_pass(login);
                        ViewBag.Message = "Password Updated";
                    
                }
            }
            else
            {
                ViewBag.Message = "not found";
            }


            dr.Close();
            cmd.ExecuteNonQuery();
            con.Close();
            return View();
        }
        public ActionResult view()
        {
            LoginViewModel lists = new LoginViewModel();
            List<Login> list = lists.GetList();
            return View(list);
        }
    }
    }